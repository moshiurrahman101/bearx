import React from 'react'
import Banner from '../components/claim/Banner'

function Claim() {
    return (
        <div>
            <Banner />
        </div>
    )
}

export default Claim
