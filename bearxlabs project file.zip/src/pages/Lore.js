import React from 'react'
import LoreContent from '../components/LoreContent'

function Lore() {
    return (
        <div>
            <LoreContent />
        </div>
    )
}

export default Lore
