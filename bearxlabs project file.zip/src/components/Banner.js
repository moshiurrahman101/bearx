import React from 'react'
function Banner() {
    return (
        <div id="banner">
            <div className="overlay">
                <div className="container">
                    <h1 >BearX Has <br />Arrived</h1>
                    <p>This project is made for fun, and will be driven by it. 
                        The community comes first, always and forever. !chomp</p>
                </div>
            </div>
        </div>
    )
}

export default Banner
